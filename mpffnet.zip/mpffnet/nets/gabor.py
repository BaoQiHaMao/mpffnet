import cv2,os
import numpy as np
import matplotlib.pyplot as plt

def get_img(input_Path):
    img_paths = []
    for (path, dirs, files) in os.walk(input_Path):
        for filename in files:
            if filename.endswith(('.jpg','.png')):
                img_paths.append(path+'/'+filename)
    return img_paths

def build_filters():
    filters = []
    ksize = [7,9,11,13,15,17]
    lamda = np.pi/2.0
    for theta in np.arange(0, np.pi, np.pi / 4):
        for K in range(6):
            kern = cv2.getGaborKernel((ksize[K], ksize[K]), 1.0, theta, lamda, 0.5, 0, ktype=cv2.CV_32F)
            kern /= 1.5*kern.sum()
            filters.append(kern)
    plt.figure(1)

    for temp in range(len(filters)):
        plt.subplot(4, 6, temp + 1)
        plt.imshow(filters[temp])
    plt.show()
    return filters

def getGabor(img, filters):
    res = []
    for i in range(len(filters)):
        accum = np.zeros_like(img)
        for kern in filters[i]:
            fimg = cv2.filter2D(img, cv2.CV_8UC1, kern)
            accum = np.maximum(accum, fimg, accum)
        res.append(np.asarray(accum))

    plt.figure(2)
    for temp in range(len(res)):
        plt.subplot(4, 6, temp+1)
        plt.imshow(res[temp], cmap='gray' )
    plt.show()
    return res

if __name__ == '__main__':
    filters = build_filters()

    img = cv2.imread('')
    getGabor(img, filters)

